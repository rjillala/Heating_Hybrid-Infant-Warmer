clc;
clear;
close all;

temp = importdata('Mar27_nofoil_vs_wfoil.txt');
hold on
length_of_trial = 15; % min
time = linspace(0, length_of_trial, length(temp));
mattTemp = plot(time, temp(:,1), 'LineWidth', 3);
aluTemp = plot(time, temp(:,2), 'LineWidth', 3);
line = zeros(length(temp)) + 37;
infantTemp = plot(time, line, 'LineWidth', 3, 'color', 'cyan');
line = zeros(length(temp)) + 31.5;
mattressTarget = plot(time, line, 'LineWidth', 3, 'color', 'magenta');
hold off
legend([mattTemp(1) aluTemp(1) infantTemp(1) mattressTarget(1)], "Room Temp, Aluminum Plate Temp, Cool Down, Acrylic w/o Foil", "Acrylic w/ Foil","Target Infant Temperature", "Target Mattress Temperature", 'Location', 'best')
ylabel('Temp (Celsius)')
ylim([15 60]);
xlabel('Time (m)- unknown time for this test')
title('Temperature of Blue Mattress 0.5" Thick at 72 V (in between pads 2 and 3)')

figure();
temp = importdata('Mar27_Two_sensor_nylon_120V_aluminum_foil.txt');
hold on
length_of_trial = 15; % min
time = linspace(0, length_of_trial, length(temp));
mattTemp = plot(time, temp(:,1), 'LineWidth', 3);
aluTemp = plot(time, temp(:,2), 'LineWidth', 3);
line = zeros(length(temp)) + 37;
infantTemp = plot(time, line, 'LineWidth', 3, 'color', 'cyan');
line = zeros(length(temp)) + 31.5;
mattressTarget = plot(time, line, 'LineWidth', 3, 'color', 'magenta');
hold off
legend([mattTemp(1) aluTemp(1) infantTemp(1) mattressTarget(1)], "Room Temp, Aluminum Plate Temp, Cool Down, Acrylic w/o Foil", "Acrylic w/ Foil","Target Infant Temperature", "Target Mattress Temperature", 'Location', 'best')
ylabel('Temp (Celsius)')
ylim([15 60]);
xlabel('Time (m)- unknown time for this test')
title('Temperature of Blue Mattress 0.5" Thick at 72 V (in between pads 2 and 3)')

figure();
temp = importdata('Mar20_Two_sensor_nylon_120V.txt');
hold on
length_of_trial = 50; % min
time = linspace(0, length_of_trial, length(temp));
mattTemp = plot(time, temp(:,1), 'LineWidth', 3);
aluTemp = plot(time, temp(:,2), 'LineWidth', 3);
line = zeros(length(temp)) + 37;
infantTemp = plot(time, line, 'LineWidth', 3, 'color', 'cyan');
line = zeros(length(temp)) + 31.5;
mattressTarget = plot(time, line, 'LineWidth', 3, 'color', 'magenta');
hold off
legend([mattTemp(1) aluTemp(1) infantTemp(1) mattressTarget(1)], "Room Temp, Aluminum Plate Temp, Cool Down, Acrylic w/o Foil", "Acrylic w/ Foil","Target Infant Temperature", "Target Mattress Temperature", 'Location', 'best')
ylabel('Temp (Celsius)')
ylim([15 60]);
xlabel('Time (m)- unknown time for this test')
title('Temperature of Blue Mattress 0.5" Thick at 72 V (in between pads 2 and 3)')
